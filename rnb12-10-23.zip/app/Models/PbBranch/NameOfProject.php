<?php

namespace App\Models\PbBranch;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class NameOfProject extends Model
{
    use HasFactory;
}
