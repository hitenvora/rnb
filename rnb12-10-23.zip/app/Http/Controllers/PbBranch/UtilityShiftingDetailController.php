<?php

namespace App\Http\Controllers\PbBranch;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class UtilityShiftingDetailController extends Controller
{
    public function index()
    {
        return view('pb_branch.utility_shifting_detail');
    }

    
}
