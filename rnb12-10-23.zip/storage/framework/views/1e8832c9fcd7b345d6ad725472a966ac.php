
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('navbar.admin.master-page.master_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body>
        <div class="breadcome-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="breadcome-list">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class="breadcome-heading">
                                        <a class="btn-left d-flex align-items-center gap-3" href="<?php echo e(route('master_form')); ?>">
                                            <span class="d-flex back-btn">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                    viewBox="0 0 24 24" fill="none">
                                                    <path
                                                        d="M7.83 11L11.41 7.41L10 6L4 12L10 18L11.41 16.59L7.83 13H20V11H7.83Z"
                                                        fill="black" />
                                                </svg>
                                            </span>
                                            <h3>User Master</h3>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-end">
                                    <a class="btn btn-white add-user" id="exportButton" href="#" download>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                                            viewBox="0 0 18 18" fill="none">
                                            <path
                                                d="M2.70117 11.4142L2.70117 14.1936C2.70117 14.6148 2.86711 15.0188 3.16248 15.3167C3.45785 15.6145 3.85846 15.7818 4.27617 15.7818H13.7262C14.1439 15.7818 14.5445 15.6145 14.8399 15.3167C15.1352 15.0188 15.3012 14.6148 15.3012 14.1936V11.4142M9.00205 2.2168V11.2168M9.00205 11.2168L12.602 7.77793M9.00205 11.2168L5.40205 7.77793"
                                                stroke-width="1.63636" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                        Export
                                    </a>
                                    <a class="btn btn-primary ms-2 add-user" data-bs-toggle="modal" data-bs-target="#add_user">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                            viewBox="0 0 20 20" fill="none">
                                            <path d="M9.99935 4.16699V15.8337M4.16602 10.0003H15.8327" stroke="white"
                                                stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                        Add User
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>

        <div class="mg-b-23">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body table-responsive p-0">
                                <table class="product-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>User Name</th>
                                            <th>Email</th>
                                            <th>Mobile No.</th>
                                            <th>Role</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>


        <!-- add user -->
        <div class="modal fade product-modal" id="add_user" tabindex="-1" aria-labelledby="add_user" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title" id="add_user">Add User</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="row" method="post" id="user_master_form">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="user_id" id="user_id">
                            <div class="col-lg-12">
                                <label class="form-label">User Name</label>
                                <input type="text" class="form-control" id="name" name="name"
                                    placeholder="Enter User Name">
                                <span class="text-danger" id="name_error"></span>
                            </div>

                            <div class="col-lg-6">
                                <label class="form-label">Email</label>
                                <input type="text" class="form-control" id="email" name="email"
                                    placeholder="Enter Email">
                                <span class="text-danger" id="email_error"></span>

                            </div>

                            <div class="col-lg-6">
                                <label class="form-label">Mobile No.</label>
                                <input type="text" class="form-control" id="mobile_no" name="mobile_no"
                                    placeholder="Enter Mobile Number">
                                <span class="text-danger" id="mobile_no_error"></span>
                            </div>

                            <div class="col-lg-6">
                                <label class="form-label">Password</label>
                                <input type="password" class="form-control" id="user_password" name="user_password"
                                    placeholder="Enter Password">
                                <span class="text-danger" id="user_password_error"></span>
                            </div>

                            <div class="col-lg-6">
                                <label class="form-label">Role</label>
                                <select class="form-select" name="role_id" id="role_id">
                                    <option>Select</option>
                                    <?php $__currentLoopData = $rolename; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger" id="role_id_error"></span>
                            </div>
                            <div class="col-12 text-center">
                                <button type="submit" class="btn submit-btn" id="btn_save"
                                    name="btn_save">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

        <!-- edit user -->
        
    </body>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        var token = "<?php echo e(csrf_token()); ?>";

        $('.edit-form').hide();
        $(document).on('click', '.add-user', function() {
            $('.modal-title').text('Add User');
            $('#user_id').val('');
            $("#user_master_form")[0].reset();
            $('span[id$="_error"]').text('');
            $('.edit-form').hide();
            $('#add_user').modal('show');
        });

        $('#user_master_form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            var csrftoken = $('meta[name="csrf-token"]').attr('content');
            $(".text-danger").text('');

            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('user_master_insert')); ?>",
                headers: {
                    'X-CSRF-Token': csrftoken,
                },
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: (data) => {
                    if (data.status == 200) {
                        $('#add_user').modal('hide');
                        if ($('#user_id').val() == '') {
                            toastr.success("User List added successfully.");
                        } else {
                            toastr.success("User List updated successfully.");
                        }
                        dataTable.draw();
                    } else {
                        toastr.error(data.msg);
                    }
                },
                error: function(response) {
                    if (response.status === 422) {
                        var errors = $.parseJSON(response.responseText);
                        $.each(errors['errors'], function(key, val) {
                            console.log(key);
                            $("#" + key + "_error").text(val[0]);
                        });
                    }
                }
            });
        });


        var dataTable = $('.product-table').DataTable({
            processing: true,
            serverSide: true,
            ordering: true,
            autoWidth: false,
            pageLength: 10,
            language: {
                search: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M17.5 17.5L13.875 13.875M15.8333 9.16667C15.8333 12.8486 12.8486 15.8333 9.16667 15.8333C5.48477 15.8333 2.5 12.8486 2.5 9.16667C2.5 5.48477 5.48477 2.5 9.16667 2.5C12.8486 2.5 15.8333 5.48477 15.8333 9.16667Z" stroke="#5E5873" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/></svg>',
                searchPlaceholder: "Search",
                oPaginate: {
                    sNext: '<i class="fa fa-angle-right" aria-hidden="true"></i>',
                    sPrevious: '<i class="fa fa-angle-left" aria-hidden="true"></i>',
                },
            },
            ajax: {
                url: "<?php echo e(route('get_user_list')); ?>",
                data: function(d) {
                    d._token = token;
                },
                type: 'POST',
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },
                {
                    data: 'name',
                    name: 'name'
                },
                {
                    data: 'email',
                    name: 'email'
                },
                {
                    data: 'mobile_no',
                    name: 'mobile_no'
                },
                {
                    data: 'role_name_view',
                    name: 'role_name_view'
                },
                {
                    data: 'action',
                    name: 'action'
                },
            ],
            drawCallback: function() {},
            initComplete: function(response) {}
        });
        function edituser(id) {
        $('span[id$="_error"]').text('');
        $.ajax({
            type: 'GET',
            url: "<?php echo e(url('user-edit')); ?>/" + id,
            headers: {
                'X-CSRF-Token': token,
            },
            dataType: "json",
            success: (data) => {
                $('.modal-title').text('Edit User');
                $("#user_master_form")[0].reset();
                $('.edit-form').show();
                // set edit value
                $('#user_id').val(data.data.id);
                $('#name').val(data.data.name);
                $('#email').val(data.data.email);
                $('#mobile_no').val(data.data.mobile_no);
                $('#role_id').val(data.data.role_id);
                // Show edit modal
                $('#add_user').modal('show');
            },
            error: function(response) {
                toastr.error(response.msg);
            }
        });
    }

    function daletetabledata(id) {
    swal.fire({
        title: "Are you sure?",
        text: "You want to delete this data!",
        icon: "warning",
        buttons: [
            'No, cancel it!',
            'Yes, I am sure!'
        ],
        dangerMode: true,
        backdrop: 'static', // Prevents clicking outside the modal to dismiss
    }).then(function(result) {
        if (result.isConfirmed) { // Check if the "Yes, I am sure!" button was clicked
            _data = {};
            _data['id'] = id;
            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('user_delete')); ?>",
                headers: {
                    'X-CSRF-Token': token,
                },
                data: _data,
                dataType: "json",
                success: (data) => {
                    dataTable.draw();
                },
                error: function(response) {}
            });
        } else {
            swal.fire("Cancelled", "Your data is safe :)", "error");
        }
    });
}

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rnb\resources\views/admin/user_master.blade.php ENDPATH**/ ?>