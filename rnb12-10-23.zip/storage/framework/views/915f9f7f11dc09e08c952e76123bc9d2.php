
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('navbar.admin.master-page.master_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body>
        <div class="breadcome-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="breadcome-list">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class="breadcome-heading">
                                        <a class="btn-left d-flex align-items-center gap-3" href="<?php echo e(route('master_form')); ?>">
                                            <span class="d-flex back-btn">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                    viewBox="0 0 24 24" fill="none">
                                                    <path
                                                        d="M7.83 11L11.41 7.41L10 6L4 12L10 18L11.41 16.59L7.83 13H20V11H7.83Z"
                                                        fill="black" />
                                                </svg>
                                            </span>
                                            <h3>Proposal Master</h3>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-end">

                                    <a class="btn btn-primary ms-2 add-division" data-bs-toggle="modal"
                                        data-bs-target="#add_proposal">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                            viewBox="0 0 20 20" fill="none">
                                            <path d="M9.99935 4.16699V15.8337M4.16602 10.0003H15.8327" stroke="white"
                                                stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                        Add Proposal
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="mg-b-23">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body table-responsive p-0">
                                <table class="product-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>District</th>
                                            <th>Taluka</th>
                                            <th>Work Type</th>
                                            <th>Type Of Work</th>
                                            <th>Budget</th>
                                            <th>Letter No.</th>
                                            <th>Date</th>
                                            <th>Amt. in Lakh</th>
                                            <th>Received From</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                    <tbody id="contactData">
                                        <tr>

                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade common-modal" id="add_proposal" tabindex="-1" aria-labelledby="add_proposal"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal_proposal">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title" id="add_finance">Add Proposal</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="row" method="post" id="proposal_master_form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="proposal_master_id" id="proposal_master_id">
                            <div class="col-lg-4">
                                <label class="form-label">District</label>
                                <select class="form-select" id="district_id" name="district_id">
                                    <option>Select District</option>
                                    <?php $__currentLoopData = $districtname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger" id="district_id_error"></span>
                            </div>
                            <div class="col-lg-4">
                                <label class="form-label">Taluka</label>
                                <select class="form-select" id="taluka_id" name="taluka_id">
                                    <option>Select Taluka</option>
                                    <?php $__currentLoopData = $talukaname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <span class="text-danger" id="taluka_id_error"></span>
                                </select>

                            </div>
                            <div class="col-lg-4">
                                <label class="form-label">Work Type</label>
                                <select class="form-select" id="work_type_id" name="work_type_id">
                                    <option>Select Work Type</option>
                                    <?php $__currentLoopData = $worktype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger" id="work_type_id_error"></span>

                            </div>
                            <div class="col-lg-3">
                                <label class="form-label">Type Of Work</label>
                                <select class="form-select" id="type_work_id" name="type_work_id">
                                    <option>Select Type Of Work</option>
                                    <?php $__currentLoopData = $typework; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger" id="type_work_id_error"></span>
                            </div>
                            <div class="col-lg-3">
                                <label class="form-label d-lg-block d-none">&nbsp;</label>
                                <input type="text" class="form-control" id="type_work" name="type_work">
                                <span class="text-danger" id="type_work_error"></span>
                            </div>
                            <div class="col-lg-3">
                                <label class="form-label">Budget</label>
                                <select class="form-select" id="budget_id" name="budget_id">
                                    <option>Select Budget</option>
                                    <?php $__currentLoopData = $budget; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <span class="text-danger" id="budget_id_error"></span>
                                </select>
                            </div>
                            <div class="col-lg-3">
                                <label class="form-label d-lg-block d-none">&nbsp;</label>
                                <input type="text" class="form-control" id="budget" name="budget">
                                <span class="text-danger" id="budget_error"></span>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-label">Budget Work / Item / Page No.</label>
                                <select class="form-select" id="budget_work_id" name="budget_work_id">
                                    <option>Select Budget Work</option>
                                    <?php $__currentLoopData = $budgetwork; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <span class="text-danger" id="budget_work_id_error"></span>
                                </select>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-label d-lg-block d-none">&nbsp;</label>
                                <input type="text" class="form-control" id="budget_work" name="budget_work">
                                <span class="text-danger" id="budget_work_error"></span>
                            </div>

                            <div class="col-lg-4">
                                <label class="form-label">Amount in Lakh</label>
                                <input type="text" class="form-control" id="amount" name="amount"
                                    placeholder="Enter Amount" value="One Lakh">
                                <span class="text-danger" id="amount_error"></span>
                            </div>
                            <div class="col-lg-4">
                                <label class="form-label">MP/MLA Suggested</label>
                                <select class="form-select" id="mp_mla_id" name="mp_mla_id">
                                    <option>Select MP/MLA Suggested</option>
                                    <?php $__currentLoopData = $mpmla; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger" id="mp_mla_id_error"></span>
                            </div>
                            <div class="col-lg-4">
                                <label class="form-label d-lg-block d-none">&nbsp;</label>
                                <input type="text" class="form-control" id="mp_mla" name="mp_mla">
                                <span class="text-danger" id="mp_mla_error"></span>
                            </div>
                            <div class="col-lg-3">
                                <label class="form-label">Letter No.</label>
                                <input type="text" class="form-control" id="letter_no" name="letter_no"
                                    value="123562123">
                                <span class="text-danger" id="letter_no_error"></span>
                            </div>
                            <div class="col-lg-3">
                                <label class="form-label">Letter Date</label>
                                <input type="date" class="form-control" id="letter_date" name="letter_date"
                                    value="2023-09-13">
                                <span class="text-danger" id="letter_date_error"></span>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-label">Letter Upload</label>
                                <div class="input-group">
                                    <input type="file" class="form-control w-100" id="upload_img" name="upload_img">
                                    <span class="text-danger" id="upload_img_error"></span>
                                </div>
                            </div>
                            <div class="col-lg-12">
                                <label class="form-label">Suggestion</label>
                                <input type="text" class="form-control" id="suggest" name="suggest"
                                    placeholder="Enter Suggestion">
                                <span class="text-danger" id="suggest_error"></span>

                            </div>
                            <div class="col-lg-12 mt-2">
                                <div class="contact_list">
                                    <h6>Received Proposal</h6>
                                    <div class="row p-0">
                                        <div class="col-lg-3">
                                            <label for="inputtitle1" class="form-label">Received Proposal From</label>
                                            <input class="form-control" type="text" id="recever_from"
                                                name="recever_from" placeholder="From">
                                            <span class="text-danger" id="recever_from_error"></span>

                                        </div>
                                        <div class="col-lg-3">
                                            <label for="inputtitle1" class="form-label">Letter No.</label>
                                            <input class="form-control" type="text" id="rec_letter_no"
                                                name="rec_letter_no" placeholder="Enter Letter No." value="100000">
                                            <span class="text-danger" id="rec_letter_no_error"></span>

                                        </div>
                                        <div class="col-lg-3">
                                            <label class="form-label">Letter Date</label>
                                            <input type="date" class="form-control" id="rec_letter_date"
                                                name="rec_letter_date" value="2023-09-13">
                                            <span class="text-danger" id="rec_letter_date_error"></span>

                                        </div>
                                        <div class="col-lg-3">
                                            <label class="form-label">Amount</label>
                                            <input type="text" class="form-control" id="rec_letter_amount"
                                                name="rec_letter_amount" value="100000">
                                            <span class="text-danger" id="rec_letter_amount_error"></span>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 mt-2">
                                <div class="contact_list">
                                    <h6>Sent Proposal</h6>
                                    <div class="row p-0">
                                        <div class="col-lg-3">
                                            <label for="inputtitle1" class="form-label">Sent Proposal To</label>
                                            <input class="form-control" type="text" id="sent_proposal"
                                                name="sent_proposal" placeholder="To">
                                            <span class="text-danger" id="sent_proposal_error"></span>

                                        </div>
                                        <div class="col-lg-3">
                                            <label for="inputtitle1" class="form-label">Letter No.</label>
                                            <input class="form-control" type="text" id="sent_proposal_letter_no"
                                                name="sent_proposal_letter_no" placeholder="Enter Letter No."
                                                value="100000">
                                            <span class="text-danger" id="sent_proposal_letter_no_error"></span>

                                        </div>
                                        <div class="col-lg-3">
                                            <label class="form-label">Letter Date</label>
                                            <input type="date" class="form-control" id="sent_proposal_date"
                                                name="sent_proposal_date" value="2023-09-13">
                                            <span class="text-danger" id="sent_proposal_date_error"></span>

                                        </div>
                                        <div class="col-lg-3">
                                            <label class="form-label">Amount</label>
                                            <input type="text" class="form-control" id="sent_proposal_amount"
                                                name="sent_proposal_amount" value="100000">
                                            <span class="text-danger" id="sent_proposal_amount_error"></span>

                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <label class="form-label">Sent Box</label>
                                <select class="form-select" id="sent_box_id" name="sent_box_id">
                                    <option>Select Sent Box</option>
                                    <?php $__currentLoopData = $sentbox; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($value['id']); ?>"><?php echo e($value['name']); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <span class="text-danger" id="sent_box_id_error"></span>

                            </div>
                            <div class="col-lg-4">
                                <label class="form-label d-lg-block d-none">&nbsp;</label>
                                <input type="text" class="form-control" id="sent_box" name="sent_box"
                                    value="Google Sheet">
                                <span class="text-danger" id="sent_box_error"></span>


                            </div>
                            <div class="col-lg-4">
                                <label class="form-label">Date</label>
                                <input type="date" class="form-control" id="sent_box_date" name="sent_box_date"
                                    value="2023-09-13">
                                <span class="text-danger" id="sent_box_date_error"></span>

                            </div>
                            <div class="col-lg-12">
                                <label class="form-label">Remarks</label>
                                <input type="text" class="form-control" id="sent_box_remark" name="sent_box_remark"
                                    placeholder="Enter Remarks...">
                                <span class="text-danger" id="sent_box_remark_error"></span>

                            </div>
                            <div class="col-12 text-center">
                                <button type="submit" class="btn submit-btn" id="btn_save"
                                    name="sub_client">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="modal fade view-modal" id="proposal_view" tabindex="-1" aria-labelledby="proposal_view"
            aria-hidden="true">
            <div class="modal-dialog modal-xl">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title" id="viewproduct">Proposal Detail</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-lg-6">
                                <table class="view-details">
                                    <tbody>
                                        <tr>
                                            <th>District</th>
                                            <td><span class="view-districts"></span></td>
                                        </tr>
                                        <tr>
                                            <th>Taluka</th>
                                            <td><span class="view-taluka"></span></td>

                                        </tr>
                                        <tr>
                                            <th>Work Type</th>
                                            <td><span class="view-work_type"></span></td>

                                        </tr>
                                        <tr>
                                            <th>Type of Work</th>
                                            <td><span class="view-type_of_work"></span></td>

                                        </tr>
                                        <tr>
                                            <th>Budget</th>
                                            <td><span class="view-budget"></span></td>

                                        </tr>
                                        <tr>
                                            <th>Budget Work / Item / Page No.</th>
                                            <td><span class="view-budget_work"></span></td>

                                        </tr>
                                        <tr>
                                            <th>Amt in Lakh</th>
                                            <td><span class="view-amount"></span></td>

                                        </tr>
                                        <tr>
                                            <th>MP/MLA Suggested</th>
                                            <td><span class="view-mp_mla"></span></td>

                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-lg-6">
                                <table class="view-details">
                                    <tbody>
                                        <tr>
                                            <th>Letter No</th>
                                            <td><span class="view-letter_no"></span></td>

                                        </tr>
                                        <tr>
                                            <th>Date</th>
                                            <td><span class="view-date"></span></td>

                                        </tr>
                                        <tr>
                                            <th>Letter Upload :</th>
                                            <td>
                                                <a href="<?php echo e(asset('assets/img/sample.png')); ?>"
                                                    class="font-primary text-decoration-underline" target="_blank">
                                                    View Image
                                                </a>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Suggestion :</th>
                                            <td><span class="view-suggestion"></span></td>

                                        </tr>
                                        <tr>
                                            <th>Sent Box :</th>
                                            <td><span class="view-sent_box"></span></td>

                                        </tr>
                                        <tr>
                                            <th>Date</th>
                                            <td><span class="view-sent_box_date"></span></td>

                                        </tr>
                                        <tr>
                                            <th>Remark : </th>
                                            <td><span class="view-remark"></span></td>

                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <div class="col-lg-6">
                                <div class="view_proposal card mb-0">
                                    <div class="card-header">
                                        <h5>Received Proposal</h5>
                                    </div>
                                    <div class="card-body">
                                        <table class="view-details">
                                            <tbody>
                                                <tr>
                                                    <th>Received Proposal From : </th>
                                                    <td><span class="view-received_proposal"></span></td>

                                                </tr>
                                                <tr>
                                                    <th>Letter No</th>
                                                    <td><span class="view-received_letter_no"></span></td>

                                                </tr>
                                                <tr>
                                                    <th>Letter Date</th>
                                                    <td><span class="view-received_letter_date"></span></td>

                                                </tr>
                                                <tr>
                                                    <th>Amount :</th>
                                                    <td><span class="view-recevid_amount"></span></td>

                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="view_proposal card mb-0">
                                    <div class="card-header">
                                        <h5>Sent Proposal</h5>
                                    </div>
                                    <div class="card-body">
                                        <table class="view-details">
                                            <tbody>
                                                <tr>
                                                    <th>Sent Proposal To : </th>
                                                    <td><span class="view-sent_proposal"></span></td>

                                                </tr>
                                                <tr>
                                                    <th>Letter No</th>
                                                    <td><span class="view-sent_letter_no"></span></td>

                                                </tr>
                                                <tr>
                                                    <th>Letter Date</th>
                                                    <td><span class="view-sent_letter_date"></span></td>

                                                </tr>
                                                <tr>
                                                    <th>Amount :</th>
                                                    <td><span class="view-sent_amount"></span></td>

                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>

    </body>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        var token = "<?php echo e(csrf_token()); ?>";

        $('.edit-form').hide();
        $(document).on('click', '.add-division', function() {
            $('.modal-title').text('Add Proposal Master');
            $('#proposal_master_id').val('');
            $("#proposal_master_form")[0].reset();
            $('span[id$="_error"]').text('');
            $('.edit-form').hide();
            $('#add_proposal').modal('show');
        });

        $('#proposal_master_form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            var csrftoken = $('meta[name="csrf-token"]').attr('content');
            $(".text-danger").text('');

            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('proposal_master_insert')); ?>",
                headers: {
                    'X-CSRF-Token': csrftoken,
                },
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: (data) => {
                    if (data.status == 200) {
                        $('#add_proposal').modal('hide');
                        if ($('#proposal_master_id').val() == '') {
                            toastr.success("Proposal Master added successfully.");
                        } else {
                            toastr.success("Proposal Master updated successfully.");
                        }
                        dataTable.draw();
                    } else {
                        toastr.error(data.msg);
                    }
                },
                error: function(response) {
                    if (response.status === 422) {
                        var errors = $.parseJSON(response.responseText);
                        $.each(errors['errors'], function(key, val) {
                            console.log(key);
                            $("#" + key + "_error").text(val[0]);
                        });
                    }
                }
            });
        });

        var dataTable = $('.product-table').DataTable({
            processing: true,
            serverSide: true,
            ordering: true,
            autoWidth: false,
            pageLength: 10,
            language: {
                search: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M17.5 17.5L13.875 13.875M15.8333 9.16667C15.8333 12.8486 12.8486 15.8333 9.16667 15.8333C5.48477 15.8333 2.5 12.8486 2.5 9.16667C2.5 5.48477 5.48477 2.5 9.16667 2.5C12.8486 2.5 15.8333 5.48477 15.8333 9.16667Z" stroke="#5E5873" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/></svg>',
                searchPlaceholder: "Search",
                oPaginate: {
                    sNext: '<i class="fa fa-angle-right" aria-hidden="true"></i>',
                    sPrevious: '<i class="fa fa-angle-left" aria-hidden="true"></i>',
                },
            },
            ajax: {
                url: "<?php echo e(route('get_proposal_master')); ?>",
                data: function(d) {
                    d._token = token;
                },
                type: 'POST',
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },
                {
                    data: 'district_name_view',
                    name: 'district_name_view'
                },
                {
                    data: 'taluka_name_view',
                    name: 'taluka_name_view'
                },
                {
                    data: 'work_type_view',
                    name: 'work_type_view'
                },
                // {
                //     data: 'type_work_view',
                //     name: 'type_work_view'
                // },
                {
                    data: 'budget',
                    name: 'budget'
                },
                {
                    data: 'letter_no',
                    name: 'letter_no'
                },
                {
                    data: 'letter_date',
                    name: 'letter_date'
                },
                {
                    data: 'amount',
                    name: 'amount'
                },
                {
                    data: 'recever_from',
                    name: 'recever_from'
                },
                {
                    data: 'sent_proposal',
                    name: 'sent_proposal'
                },
                {
                    data: 'action',
                    name: 'action'
                },

            ],
            drawCallback: function() {},
            initComplete: function(response) {}
        });


        function editproposal(id) {
            $('span[id$="_error"]').text('');
            $.ajax({
                type: 'GET',
                url: "<?php echo e(url('proposal-master-edit')); ?>/" + id,
                headers: {
                    'X-CSRF-Token': token,
                },
                dataType: "json",
                success: (data) => {
                    $('.modal-title').text('Edit Proposl Master Letter');
                    $("#proposal_master_form")[0].reset();
                    $('.edit-form').show();
                    // set edit value
                    $('#proposal_master_id').val(data.data.id);
                    $('#district_id').val(data.data.district_id);
                    $('#taluka_id').val(data.data.taluka_id);
                    $('#work_type_id').val(data.data.work_type_id);
                    $('#type_work_id').val(data.data.type_work_id);
                    $('#type_work').val(data.data.type_work);
                    $('#budget_id').val(data.data.budget_id);
                    $('#budget').val(data.data.budget);
                    $('#budget_work_id').val(data.data.budget_work_id);
                    $('#budget_work').val(data.data.budget_work);
                    $('#amount').val(data.data.amount);
                    $('#mp_mla_id').val(data.data.mp_mla_id);
                    $('#mp_mla').val(data.data.mp_mla);
                    $('#letter_no').val(data.data.letter_no);
                    $('#letter_date').val(data.data.letter_date);
                    $('#suggest').val(data.data.suggest);
                    $('#recever_from').val(data.data.recever_from);
                    $('#rec_letter_no').val(data.data.rec_letter_no);
                    $('#rec_letter_date').val(data.data.rec_letter_date);
                    $('#rec_letter_amount').val(data.data.rec_letter_amount);
                    $('#sent_proposal').val(data.data.sent_proposal);
                    $('#sent_proposal_letter_no').val(data.data.sent_proposal_letter_no);
                    $('#sent_proposal_date').val(data.data.sent_proposal_date);
                    $('#sent_proposal_amount').val(data.data.sent_proposal_amount);
                    $('#sent_box_id').val(data.data.sent_box_id);
                    $('#sent_box').val(data.data.sent_box);
                    $('#sent_box_date').val(data.data.sent_box_date);
                    $('#sent_box_remark').val(data.data.sent_box_remark);



                    // Show edit modal
                    $('#add_proposal').modal('show');
                },
                error: function(response) {
                    toastr.error(response.msg);
                }
            });
        }

        function daletetabledata(id) {
            swal.fire({
                title: "Are you sure?",
                text: "You want to delete this data!",
                icon: "warning",
                buttons: [
                    'No, cancel it!',
                    'Yes, I am sure!'
                ],
                dangerMode: true,
                backdrop: 'static', // Prevents clicking outside the modal to dismiss
            }).then(function(result) {
                if (result.isConfirmed) { // Check if the "Yes, I am sure!" button was clicked
                    _data = {};
                    _data['id'] = id;
                    $.ajax({
                        type: 'POST',
                        url: "<?php echo e(route('proposal_delete')); ?>",
                        headers: {
                            'X-CSRF-Token': token,
                        },
                        data: _data,
                        dataType: "json",
                        success: (data) => {
                            dataTable.draw();
                        },
                        error: function(response) {}
                    });
                } else {
                    swal.fire("Cancelled", "Your data is safe :)", "error");
                }
            });
        }


        function viewproposal(id) {
            $('span[id$="_error"]').text('');
            $('.view-districts').text("");
            $('.view-taluka').text("");
            $('.view-work_type').text("");
            $('.view-type_of_work').text("");
            $('.view-budget').text("");
            $('.view-budget_work').text("");
            $('.view-amount').text("");
            $('.view-mp_mla').text("");
            $('.view-letter_no').text("");
            $('.view-date').text("");
            $('.view-suggestion').text("");
            $('.view-sent_box').text("");
            $('.view-sent_box_date').text("");
            $('.view-remark').text("");
            $('.view-received_proposal').text("");
            $('.view-received_letter_no').text("");
            $('.view-received_letter_date').text("");
            $('.view-recevid_amount').text("");
            $('.view-sent_proposal').text("");
            $('.view-sent_letter_no').text("");
            $('.view-sent_letter_date').text("");
            $('.view-sent_amount').text("");



            // $('.view-city').text("");
            // $('.view-address').text("");
            // $('.view-map-location').attr('href', "");
            $.ajax({
                type: 'GET',
                url: "<?php echo e(url('show-proposal-master')); ?>/" + id,
                headers: {
                    'X-CSRF-Token': token,
                },
                dataType: "json",
                success: (data) => {
                    console.log('id', id);
                    $('.view-districts').text(data.data.district_name.name);
                    $('.view-taluka').text(data.data.taluka_name.name);
                    $('.view-work_type').text(data.data.work_type.name);
                    $('.view-type_of_work').text(data.data.type_work.name);
                    $('.view-budget').text(data.data.budget);
                    $('.view-budget_work').text(data.data.budgetwork_name.name);
                    $('.view-amount').text(data.data.amount);
                    $('.view-mp_mla').text(data.data.mla_name.name);
                    $('.view-letter_no').text(data.data.letter_no);
                    $('.view-date').text(data.data.letter_date);
                    $('.view-suggestion').text(data.data.suggest);
                    $('.view-sent_box').text(data.data.sent_box_name.name);
                    $('.view-sent_box_date').text(data.data.sent_box_date);
                    $('.view-remark').text(data.data.sent_box_remark);
                    $('.view-received_proposal').text(data.data.recever_from);
                    $('.view-received_letter_no').text(data.data.rec_letter_no);
                    $('.view-received_letter_date').text(data.data.rec_letter_date);
                    $('.view-recevid_amount').text(data.data.rec_letter_amount);
                    $('.view-sent_proposal').text(data.data.sent_proposal);
                    $('.view-sent_letter_no').text(data.data.sent_proposal_letter_no);
                    $('.view-sent_letter_date').text(data.data.sent_proposal_date);
                    $('.view-sent_amount').text(data.data.sent_proposal_amount);

                    // $('.view-city').text(data.data.city);
                    // $('.view-address').text(data.data.address);
                    // $('.view-map-location').attr('href', data.data.g_map_location);
                    // $('.view-g_map_location ').text(data.data.g_map_location);

                    $('#contactData');
                    $('.modal-title').text('View Proposal');
                    $('.edit-form').show();
                    // set edit value
                    $('#proposal_view').modal('show');
                },
                error: function(response) {
                    toastr.error(response.msg);
                }
            });

        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rnb\resources\views/admin/proposal_master.blade.php ENDPATH**/ ?>