
<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('navbar.admin.master-page.master_navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <body>
        <div class="breadcome-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                        <div class="breadcome-list">
                            <div class="row">
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                    <div class="breadcome-heading">
                                        <a class="btn-left d-flex align-items-center gap-3 letter-reminder"
                                            href="<?php echo e(route('master_form')); ?>">
                                            <span class="d-flex back-btn">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
                                                    viewBox="0 0 24 24" fill="none">
                                                    <path
                                                        d="M7.83 11L11.41 7.41L10 6L4 12L10 18L11.41 16.59L7.83 13H20V11H7.83Z"
                                                        fill="black" />
                                                </svg>
                                            </span>
                                            <h3>Letter Reminder Master</h3>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12 text-end">
                                    <a class="btn btn-white" href="#" id="exportButton" download>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18"
                                            viewBox="0 0 18 18" fill="none">
                                            <path
                                                d="M2.70117 11.4142L2.70117 14.1936C2.70117 14.6148 2.86711 15.0188 3.16248 15.3167C3.45785 15.6145 3.85846 15.7818 4.27617 15.7818H13.7262C14.1439 15.7818 14.5445 15.6145 14.8399 15.3167C15.1352 15.0188 15.3012 14.6148 15.3012 14.1936V11.4142M9.00205 2.2168V11.2168M9.00205 11.2168L12.602 7.77793M9.00205 11.2168L5.40205 7.77793"
                                                stroke-width="1.63636" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                        Export
                                    </a>
                                    <a class="btn btn-primary ms-2 letter-reminder" data-bs-toggle="modal"
                                        data-bs-target="#add_letter">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20"
                                            viewBox="0 0 20 20" fill="none">
                                            <path d="M9.99935 4.16699V15.8337M4.16602 10.0003H15.8327" stroke="white"
                                                stroke-width="1.67" stroke-linecap="round" stroke-linejoin="round" />
                                        </svg>
                                        Add Letter Reminder
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>
        <div class="mg-b-23">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-body table-responsive p-0">
                                <table class="product-table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>Date</th>
                                            <th>Subject</th>
                                            <th class="text-center">Letter Upload</th>
                                            <th>Submitted To</th>
                                            <th>Expired Date</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade product-modal" id="add_letter" tabindex="-1" aria-labelledby="add_letter"
            aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h2 class="modal-title" id="add_finance">Add Letter Reminder</h2>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form class="row" method="post" id="letter_reminder_form" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="letter_reminder_id" id="letter_reminder_id">
                            <div class="col-lg-6">
                                <label class="form-label">Date</label>
                                <input type="date" class="form-control" id="date" name="date" value="2023-09-13">
                                <span class="text-danger" id="date_error"></span>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-label">Subject</label>
                                <input type="text" class="form-control" id="subject" name="subject"
                                    placeholder="Enter Subject">
                                <span class="text-danger" id="subject_error"></span>
                            </div>
                            <div class="col-lg-12">
                                <label class="form-label">Letter Upload</label>
                                <div class="input-group">
                                    <input type="file" class="form-control w-100" id="upload_img" name="upload_img">
                                </div>
                                <span class="text-danger" id="upload_img_error"></span>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-label">Submitted To</label>
                                <input type="text" class="form-control" id="submit_to" name="submit_to"
                                    placeholder="Enter Submitted To">
                                <span class="text-danger" id="submit_to_error"></span>
                            </div>
                            <div class="col-lg-6">
                                <label class="form-label">Expired Date</label>
                                <input type="date" class="form-control" id="expire_date" name="expire_date"
                                    value="2023-09-13">
                                <div class="col-lg-6 edit-form">
                                    <label for="inputtitle1" class="form-label">Is Active</label>
                                    <select class="form-select" name="is_active" id="is_active">
                                        <option value="1">Is active</option>
                                        <option value="0">Inactive</option>
                                    </select>
                                    <span class="text-danger" id="is_active_error"></span>
                                </div>
                            </div>
                            <div class="col-12 text-center">
                                <button type="submit" class="btn submit-btn" id="btn_save"
                                    name="sub_client">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
        </div>

    </body>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        var token = "<?php echo e(csrf_token()); ?>";

        $('.edit-form').hide();
        $(document).on('click', '.letter-reminder', function() {
            $('.modal-title').text('Add Letter Reminder Division');
            $('#letter_reminder_id').val('');
            $("#letter_reminder_form")[0].reset();
            $('span[id$="_error"]').text('');
            $('.edit-form').hide();
            $('add_letter').modal('show');
        });

        $('#letter_reminder_form').submit(function(e) {
            e.preventDefault();
            var formData = new FormData(this);
            var csrftoken = $('meta[name="csrf-token"]').attr('content');
            $(".text-danger").text('');

            $.ajax({
                type: 'POST',
                url: "<?php echo e(route('letter_reminder_insert')); ?>",
                headers: {
                    'X-CSRF-Token': csrftoken,
                },
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: (data) => {
                    if (data.status == 200) {
                        $('#add_letter').modal('hide');
                        if ($('#letter_reminder_id').val() == '') {
                            toastr.success("Letter Reminder List added successfully.");
                        } else {
                            toastr.success("Letter Reminder List updated successfully.");
                        }
                        dataTable.draw();
                    } else {
                        toastr.error(data.msg);
                    }
                },
                error: function(response) {
                    if (response.status === 422) {
                        var errors = $.parseJSON(response.responseText);
                        $.each(errors['errors'], function(key, val) {
                            console.log(key);
                            $("#" + key + "_error").text(val[0]);
                        });
                    }
                }
            });
        });


        var dataTable = $('.product-table').DataTable({
            processing: true,
            serverSide: true,
            ordering: true,
            autoWidth: false,
            pageLength: 10,
            language: {
                search: '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none"><path d="M17.5 17.5L13.875 13.875M15.8333 9.16667C15.8333 12.8486 12.8486 15.8333 9.16667 15.8333C5.48477 15.8333 2.5 12.8486 2.5 9.16667C2.5 5.48477 5.48477 2.5 9.16667 2.5C12.8486 2.5 15.8333 5.48477 15.8333 9.16667Z" stroke="#5E5873" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/></svg>',
                searchPlaceholder: "Search",
                oPaginate: {
                    sNext: '<i class="fa fa-angle-right" aria-hidden="true"></i>',
                    sPrevious: '<i class="fa fa-angle-left" aria-hidden="true"></i>',
                },
            },
            ajax: {
                url: "<?php echo e(route('get_letter_reminder')); ?>",
                data: function(d) {
                    d._token = token;
                },
                type: 'POST',
            },
            columns: [{
                    data: 'DT_RowIndex',
                    name: 'DT_RowIndex'
                },
                {
                    data: 'date',
                    name: 'date'
                },
                {
                    data: 'subject',
                    name: 'subject'
                },
                {
                    data: 'eye_icon',
                    name: 'eye_icon'
                },
                {
                    data: 'submit_to',
                    name: 'submit_to'
                },
                {
                    data: 'expire_date',
                    name: 'expire_date'
                },
                {
                    data: 'active_button',
                    name: 'active_button'
                },
                {
                    data: 'action',
                    name: 'action'
                },

            ],
            drawCallback: function() {},
            initComplete: function(response) {}
        });

        function editsubdivision(id) {
            $('span[id$="_error"]').text('');
            $.ajax({
                type: 'GET',
                url: "<?php echo e(url('letter-reminder-edit')); ?>/" + id,
                headers: {
                    'X-CSRF-Token': token,
                },
                dataType: "json",
                success: (data) => {
                    $('.modal-title').text('Edit Letter Reminder Letter');
                    $("#letter_reminder_form")[0].reset();
                    $('.edit-form').show();
                    // set edit value
                    $('#letter_reminder_id').val(data.data.id);
                    $('#date').val(data.data.date);
                    $('#subject').val(data.data.subject);
                    $('#submit_to').val(data.data.submit_to);
                    $('#expire_date').val(data.data.expire_date);

                    // Show edit modal
                    $('#add_letter').modal('show');
                },
                error: function(response) {
                    toastr.error(response.msg);
                }
            });
        }

        function daletetabledata(id) {
            swal.fire({
                title: "Are you sure?",
                text: "You want to delete this data!",
                icon: "warning",
                buttons: [
                    'No, cancel it!',
                    'Yes, I am sure!'
                ],
                dangerMode: true,
                backdrop: 'static', // Prevents clicking outside the modal to dismiss
            }).then(function(result) {
                if (result.isConfirmed) { // Check if the "Yes, I am sure!" button was clicked
                    _data = {};
                    _data['id'] = id;
                    $.ajax({
                        type: 'POST',
                        url: "<?php echo e(route('letter_reminder_delete')); ?>",
                        headers: {
                            'X-CSRF-Token': token,
                        },
                        data: _data,
                        dataType: "json",
                        success: (data) => {
                            dataTable.draw();
                        },
                        error: function(response) {}
                    });
                } else {
                    swal.fire("Cancelled", "Your data is safe :)", "error");
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rnb\resources\views/admin/letter_reminder_master.blade.php ENDPATH**/ ?>