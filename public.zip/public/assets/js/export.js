document.getElementById("exportButton").addEventListener("click", function() {
  // Get the table element
  const table = document.getElementById("product-table");
  
  // Create a new CSV content
  let csvContent = "data:text/csv;charset=utf-8,";
  
  // Loop through the rows and cells of the table
  for (const row of table.rows) {
    const rowData = [];
    for (const cell of row.cells) {
      rowData.push(cell.innerText);
    }
    // Combine cell data into a CSV row
    const rowCSV = rowData.join(",");
    csvContent += rowCSV + "\r\n";
  }
  
  // Create a temporary link element to trigger the download
  const link = document.createElement("a");
  link.href = encodeURI(csvContent);
  link.target = "_blank";
  link.download = "table_data.csv"; // Change the filename as needed
  document.body.appendChild(link);
  
  // Trigger the download
  link.click();
  
  // Clean up the temporary link element
  document.body.removeChild(link);
});